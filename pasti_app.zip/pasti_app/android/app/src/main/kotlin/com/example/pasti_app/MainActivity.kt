package com.example.pasti_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
