import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:pasti/core/models/financial_report.dart';

class FinancialChart extends StatelessWidget {
  final List<FinancialReport> financialReports;

  const FinancialChart({super.key, required this.financialReports});

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1.7,
      child: BarChart(
        BarChartData(
          barTouchData: BarTouchData(
            touchTooltipData: BarTouchTooltipData(
                tooltipBgColor: Colors.blueGrey,
                getTooltipItem: (group, groupIndex, rod, rodIndex) {
                  return BarTooltipItem(
                      "Pemasukan : ${financialReports[groupIndex].income.toString()},\nPengeluaran : ${financialReports[groupIndex].expense.toString()},\nSaldo : ${financialReports[groupIndex].balance.toString()}",
                      const TextStyle(color: Colors.white));
                }),
          ),
          titlesData: FlTitlesData(
            show: true,
            bottomTitles: AxisTitles(
                sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (value, meta) {
                final index = value.toInt();
                if (index >= 0 && index < financialReports.length) {
                  return Text(
                    financialReports[index].tanggal,
                    style: Theme.of(context).textTheme.bodySmall,
                    textAlign: TextAlign.center,
                  );
                }
                return const Text("");
              },
              reservedSize: 30,
            )),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
            topTitles: AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
            rightTitles: AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
          ),
          borderData: FlBorderData(
            show: false,
          ),
          barGroups: _generateBarGroups(),
          gridData: FlGridData(show: false),
        ),
      ),
    );
  }

  List<BarChartGroupData> _generateBarGroups() {
    return List.generate(financialReports.length, (index) {
      final report = financialReports[index];
      return BarChartGroupData(
        x: index,
        barRods: [
          BarChartRodData(
              toY: report.balance >= 0 ? report.balance : 0,
              color: Colors.green,
              width: 15),
          BarChartRodData(
              toY: report.balance < 0 ? report.balance : 0,
              color: Colors.red,
              width: 15),
        ],
      );
    });
  }
}
