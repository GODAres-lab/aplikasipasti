import 'package:flutter/material.dart';
import 'package:pasti/ui/screens/management_screen.dart';
import 'package:url_launcher/url_launcher.dart';

class AppNavbar extends StatelessWidget {
  const AppNavbar({super.key});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Image.asset(
            "assets/images/logo.png",
            height: 40,
          ),
          Row(
            children: [
              TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ManagementScreen(),
                    ),
                  );
                },
                child: const Text(
                  "Management",
                  style: TextStyle(color: Colors.white),
                ),
              ),
              IconButton(
                onPressed: () async {
                  final url = Uri.parse("https://agreeculture.id/");
                  if (await canLaunchUrl(url)) {
                    launchUrl(url);
                  } else {
                    print("tidak dapat membuka url");
                  }
                },
                icon: const Icon(
                  Icons.web,
                  color: Colors.white,
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}
