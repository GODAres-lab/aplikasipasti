import 'package:flutter/material.dart';
import 'package:pasti/core/constants/colors.dart';
import 'package:pasti/ui/screens/home_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  final List<Map<String, String>> _onboardingPages = [
    {
      "image": "assets/images/onboarding1.png",
      "title": "Selamat Datang di PASTI",
      "description":
          "Aplikasi yang dirancang khusus untuk membantu petani padi dalam mengelola pertanian mereka.",
    },
    {
      "image": "assets/images/onboarding2.png",
      "title": "Informasi Pertanian Terlengkap",
      "description":
          "Dapatkan informasi lengkap mengenai hama, penyakit, pengendalian, dan ilmu pertanian padi lainnya.",
    },
    {
      "image": "assets/images/onboarding3.png",
      "title": "Manajemen Lahan yang Efektif",
      "description":
          "Atur kebutuhan pupuk, jadwal pemupukan, dan pantau laporan keuangan pertanian Anda dengan mudah.",
    },
  ];

  @override
  void initState() {
    super.initState();
    _checkFirstRun();
  }

  void _checkFirstRun() async {
    final prefs = await SharedPreferences.getInstance();
    final isFirstRun = prefs.getBool('isFirstRun') ?? true;
    if (!isFirstRun) {
      _navigateToHome();
    }
  }

  void _navigateToHome() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const HomeScreen()),
    );
  }

  void _setFirstRun() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setBool('isFirstRun', false);
    _navigateToHome();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: PageView.builder(
              controller: _pageController,
              itemCount: _onboardingPages.length,
              onPageChanged: (value) {
                setState(() {
                  _currentPage = value;
                  print("Current Page: $_currentPage"); // Debug
                });
              },
              itemBuilder: (context, index) {
                return OnboardingPage(
                    image: _onboardingPages[index]["image"]!,
                    title: _onboardingPages[index]["title"]!,
                    description: _onboardingPages[index]["description"]!);
              },
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              _onboardingPages.length,
              (index) => _buildDot(index),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: _currentPage == _onboardingPages.length - 1
                ? ElevatedButton(
                    onPressed: _setFirstRun,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryColor,
                      minimumSize: const Size(double.infinity, 50),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: const Text(
                      "Mulai",
                      style: TextStyle(color: Colors.white),
                    ),
                  )
                : const SizedBox.shrink(),
          )
        ],
      ),
    );
  }

  Widget _buildDot(int index) {
    return Container(
      margin: const EdgeInsets.all(5),
      width: 8,
      height: 8,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: _currentPage == index ? AppColors.primaryColor : Colors.grey,
      ),
    );
  }
}

class OnboardingPage extends StatelessWidget {
  final String image;
  final String title;
  final String description;

  const OnboardingPage({
    super.key,
    required this.image,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            image,
            width: 250,
          ),
          const SizedBox(
            height: 20,
          ),
          Text(
            title,
            style: Theme.of(context).textTheme.headlineMedium,
            textAlign: TextAlign.center,
          ),
          const SizedBox(
            height: 10,
          ),
          Text(
            description,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyLarge,
          ),
        ],
      ),
    );
  }
}
