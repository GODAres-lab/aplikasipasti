import 'package:flutter/material.dart';
import 'package:pasti/core/models/card_info.dart';
import 'package:pasti/core/models/search_history.dart';
import 'package:pasti/providers/card_provider.dart';
import 'package:pasti/ui/widgets/card_widget.dart';
import 'package:pasti/ui/widgets/custom_search_bar.dart';
import 'package:provider/provider.dart';
import 'package:pasti/core/utils/database_helper.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  List<CardInfo> _searchResults = [];
  List<SearchHistory> _searchHistory = [];
  final dbHelper = DatabaseHelper.instance;

  @override
  void initState() {
    super.initState();
    _loadSearchHistory();
  }

  void _loadSearchHistory() async {
    final history = await dbHelper.getSearchHistory();
    setState(() {
      _searchHistory = history;
    });
  }

  void _clearSearchHistory() async {
    await dbHelper.deleteAllSearchHistory();
    _loadSearchHistory();
  }

  void _deleteSearchHistory(int id) async {
    await dbHelper.deleteSearchHistory(id);
    _loadSearchHistory();
  }

  void _searchCards(String query) async {
    final cardProvider = Provider.of<CardProvider>(context, listen: false);
    if (query.isNotEmpty) {
      final history = SearchHistory(
          query: query, timestamp: DateTime.now().millisecondsSinceEpoch);
      await dbHelper.insertSearchHistory(history);
      _loadSearchHistory();
    }
    if (query.isEmpty) {
      setState(() {
        _searchResults = [];
      });
      return;
    }
    setState(() {
      _searchResults = cardProvider.cardList
          .where((card) =>
              card.title.toLowerCase().contains(query.toLowerCase()) ||
              card.subtitle.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Search",
          style: TextStyle(color: Colors.white),
        ),
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Column(
        children: [
          CustomSearchBar(
            onChanged: _searchCards,
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Riwayat Pencarian",
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                TextButton(
                    onPressed: _clearSearchHistory,
                    child: const Text(
                      "Hapus Semua",
                      style: TextStyle(color: Colors.red),
                    ))
              ],
            ),
          ),
          Expanded(
            child: _searchResults.isEmpty
                ? _searchHistory.isEmpty
                    ? const Center(
                        child: Text(
                            'Tidak ada hasil pencarian atau riwayat pencarian.'),
                      )
                    : ListView.builder(
                        itemCount: _searchHistory.length,
                        itemBuilder: (context, index) {
                          final history = _searchHistory[index];
                          return Dismissible(
                            key: UniqueKey(),
                            onDismissed: (direction) {
                              _deleteSearchHistory(history.id!);
                            },
                            background: Container(
                              color: Colors.red,
                              alignment: Alignment.centerRight,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 20),
                              child: const Icon(
                                Icons.delete,
                                color: Colors.white,
                              ),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 8),
                              child: ListTile(
                                  title: Text(
                                    history.query,
                                    style:
                                        Theme.of(context).textTheme.bodyLarge,
                                  ),
                                  trailing: Text(
                                    DateTime.fromMillisecondsSinceEpoch(
                                            history.timestamp)
                                        .toString()
                                        .split(".")[0],
                                    style:
                                        Theme.of(context).textTheme.bodySmall,
                                  )),
                            ),
                          );
                        },
                      )
                : ListView.builder(
                    itemCount: _searchResults.length,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                        child: CardWidget(cardInfo: _searchResults[index]),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
