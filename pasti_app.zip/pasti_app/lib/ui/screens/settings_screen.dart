import 'package:flutter/material.dart';
import 'package:pasti/core/constants/colors.dart';
import 'package:pasti/ui/theme/app_theme.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _isDarkMode = false;

  @override
  void initState() {
    super.initState();
    _loadTheme();
  }

  Future<void> _loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final isDarkMode = prefs.getBool("isDarkMode") ?? false;
    setState(() {
      _isDarkMode = isDarkMode;
    });
    _updateTheme(isDarkMode);
  }

  Future<void> _updateTheme(bool isDarkMode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isDarkMode', isDarkMode);
    Provider.of<ThemeNotifier>(context, listen: false).setTheme(isDarkMode);
  }

  void _toggleTheme(bool value) async {
    setState(() {
      _isDarkMode = value;
    });
    _updateTheme(value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Pengaturan",
          style: TextStyle(color: Colors.white),
        ),
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Tema Gelap",
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                Switch(
                  value: _isDarkMode,
                  onChanged: _toggleTheme,
                  activeColor: AppColors.primaryColor,
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
