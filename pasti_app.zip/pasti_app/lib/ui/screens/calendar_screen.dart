import 'package:flutter/material.dart';
import 'package:pasti/core/utils/database_helper.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key});

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  final dbHelper = DatabaseHelper.instance;
  List<DateTime> _schedule = [];
  Map<DateTime, List<String>> _events = {};

  @override
  void initState() {
    super.initState();
    _loadSchedule();
  }

  void _loadSchedule() async {
    final prefs = await SharedPreferences.getInstance();
    final selectedTimeHour = prefs.getInt("notificationTimeHour") ?? 8;
    final selectedTimeMinute = prefs.getInt("notificationTimeMinute") ?? 0;
    final now = DateTime.now();
    final scheduleList = [
      DateTime(
          now.year, now.month, now.day, selectedTimeHour, selectedTimeMinute),
      DateTime(now.year, now.month, now.day, selectedTimeHour,
              selectedTimeMinute)
          .add(const Duration(days: 7)),
      DateTime(now.year, now.month, now.day, selectedTimeHour,
              selectedTimeMinute)
          .add(const Duration(days: 14))
    ];
    setState(() {
      _schedule = scheduleList;
    });
    _generateEvents();
  }

  void _generateEvents() {
    setState(() {
      _events = {
        for (final date in _schedule) date: ['Jadwal Pemupukan']
      };
    });
  }

  List<String> _getEventsForDay(DateTime day) {
    return _events[day] ?? [];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text(
            "Kalender",
            style: TextStyle(color: Colors.white),
          ),
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              TableCalendar(
                focusedDay: _focusedDay,
                firstDay: DateTime.utc(2010, 10, 16),
                lastDay: DateTime.utc(2030, 3, 14),
                calendarFormat: CalendarFormat.month,
                eventLoader: _getEventsForDay,
                selectedDayPredicate: (day) {
                  return isSameDay(_selectedDay, day);
                },
                onDaySelected: (selectedDay, focusedDay) {
                  setState(() {
                    _selectedDay = selectedDay;
                    _focusedDay =
                        focusedDay; // update `_focusedDay` here as well
                  });
                },
              ),
              const SizedBox(
                height: 20,
              ),
              Expanded(
                  child: ListView.builder(
                      itemCount:
                          _getEventsForDay(_selectedDay ?? _focusedDay).length,
                      itemBuilder: (context, index) {
                        final event = _getEventsForDay(
                            _selectedDay ?? _focusedDay)[index];
                        return ListTile(
                            title: Text(
                          event,
                          style: Theme.of(context).textTheme.bodyMedium,
                        ));
                      }))
            ],
          ),
        ));
  }
}
