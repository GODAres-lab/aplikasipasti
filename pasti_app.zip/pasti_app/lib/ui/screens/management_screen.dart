import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:pasti/core/constants/colors.dart';
import 'package:pasti/core/utils/helpers.dart';
import 'package:pasti/core/utils/database_helper.dart';
import 'package:pasti/core/models/financial_report.dart';
import 'package:pasti/ui/widgets/financial_chart.dart';

class ManagementScreen extends StatefulWidget {
  const ManagementScreen({super.key});

  @override
  State<ManagementScreen> createState() => _ManagementScreenState();
}

class _ManagementScreenState extends State<ManagementScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _nitrogenController = TextEditingController();
  final TextEditingController _phosphorusController = TextEditingController();
  final TextEditingController _potassiumController = TextEditingController();
  String _recommendation = "";
  List<DateTime> _schedule = [];
  final TextEditingController _incomeController = TextEditingController();
  final TextEditingController _expenseController = TextEditingController();
  double _balance = 0;
  final dbHelper = DatabaseHelper.instance;
  List<FinancialReport> _financialReports = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadFinancialReports();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _nitrogenController.dispose();
    _phosphorusController.dispose();
    _potassiumController.dispose();
    super.dispose();
  }

  void _loadFinancialReports() async {
    final reports = await dbHelper.getFinancialReports();
    setState(() {
      _financialReports = reports;
    });
  }

  void _clearFinancialReports() async {
    await dbHelper.deleteAllFinancialReport();
    _loadFinancialReports();
  }

  void _deleteFinancialReport(int id) async {
    await dbHelper.deleteFinancialReport(id);
    _loadFinancialReports();
  }

  void _calculateFertilizer() {
    final nitrogen = int.tryParse(_nitrogenController.text) ?? 0;
    final phosphorus = int.tryParse(_phosphorusController.text) ?? 0;
    final potassium = int.tryParse(_potassiumController.text) ?? 0;
    final recommendation = calculateFertilizer(nitrogen, phosphorus, potassium);
    setState(() {
      _recommendation = recommendation;
    });
  }

  void _generateSchedule() {
    final now = DateTime.now();
    final scheduleList = [
      now,
      now.add(const Duration(days: 7)),
      now.add(const Duration(days: 14)),
    ];
    setState(() {
      _schedule = scheduleList;
    });
  }

  void _calculateFinancial() async {
    final income = double.tryParse(_incomeController.text) ?? 0;
    final expense = double.tryParse(_expenseController.text) ?? 0;
    final balance = income - expense;

    final report = FinancialReport(
        tanggal: DateFormat('dd-MM-yyyy').format(DateTime.now()),
        income: income,
        expense: expense,
        balance: balance);
    await dbHelper.insertFinancialReport(report);
    setState(() {
      _balance = balance;
    });
    _loadFinancialReports();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Management Lahan",
          style: TextStyle(color: Colors.white),
        ),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: "Pupuk"),
            Tab(text: "Jadwal"),
            Tab(text: "Keuangan"),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildFertilizerTab(),
          _buildScheduleTab(),
          _buildFinanceTab(),
        ],
      ),
    );
  }

  Widget _buildFertilizerTab() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Analisis Kebutuhan Pupuk",
              style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(
            height: 10,
          ),
          TextField(
            controller: _nitrogenController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: "Nitrogen (N)"),
          ),
          TextField(
            controller: _phosphorusController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: "Fosfor (P)"),
          ),
          TextField(
            controller: _potassiumController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: "Kalium (K)"),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: _calculateFertilizer,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryColor,
            ),
            child: const Text(
              "Hitung Kebutuhan Pupuk",
              style: TextStyle(color: Colors.white),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Text(
            "Rekomendasi: $_recommendation",
            style: Theme.of(context).textTheme.bodyLarge,
          )
        ],
      ),
    );
  }

  Widget _buildScheduleTab() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Jadwal Pemupukan",
              style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 10),
          ElevatedButton(
              onPressed: _generateSchedule,
              style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryColor),
              child: const Text(
                "Generate Jadwal",
                style: TextStyle(color: Colors.white),
              )),
          const SizedBox(height: 20),
          Expanded(
            child: ListView.builder(
                itemCount: _schedule.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(
                      "Pemupukan ke ${index + 1}",
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                    trailing: Text(
                      DateFormat('dd-MM-yyyy').format(_schedule[index]),
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  );
                }),
          )
        ],
      ),
    );
  }

  Widget _buildFinanceTab() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Laporan Keuangan",
              style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 10),
          TextField(
            controller: _incomeController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: "Pemasukan"),
          ),
          TextField(
            controller: _expenseController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: "Pengeluaran"),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: _calculateFinancial,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryColor,
            ),
            child: const Text(
              "Hitung Keuangan",
              style: TextStyle(color: Colors.white),
            ),
          ),
          const SizedBox(height: 10),
          Text(
            "Saldo: $_balance",
            style: Theme.of(context).textTheme.bodyLarge,
          ),
          const SizedBox(height: 20),
          _financialReports.isNotEmpty
              ? FinancialChart(financialReports: _financialReports)
              : const Center(
                  child: Text("Tidak ada data keuangan"),
                ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Riwayat Keuangan",
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                TextButton(
                    onPressed: _clearFinancialReports,
                    child: const Text(
                      "Hapus Semua",
                      style: TextStyle(color: Colors.red),
                    ))
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _financialReports.length,
              itemBuilder: (context, index) {
                final report = _financialReports[index];
                return Dismissible(
                    key: UniqueKey(),
                    onDismissed: (direction) {
                      _deleteFinancialReport(report.id!);
                    },
                    background: Container(
                      color: Colors.red,
                      alignment: Alignment.centerRight,
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: const Icon(
                        Icons.delete,
                        color: Colors.white,
                      ),
                    ),
                    child: ListTile(
                        title: Text("Tanggal : ${report.tanggal}"),
                        subtitle: Text(
                            "Pemasukan : ${report.income}, Pengeluaran : ${report.expense}, Saldo : ${report.balance}")));
              },
            ),
          )
        ],
      ),
    );
  }
}
