import 'package:flutter/material.dart';
import 'package:pasti/core/constants/colors.dart';

import '../../core/constants/text_styles.dart';

class AppTheme {
  static ThemeData get lightTheme {
    return ThemeData(
        primaryColor: AppColors.primaryColor,
        hintColor: AppColors.textLightColor,
        scaffoldBackgroundColor: AppColors.backgroundColor,
        appBarTheme: AppBarTheme(
          color: AppColors.primaryColor,
          titleTextStyle: AppTextStyles.headline2.copyWith(color: Colors.white),
        ),
        textTheme: TextTheme(
          headlineLarge: AppTextStyles.headline1,
          headlineMedium: AppTextStyles.headline2,
          headlineSmall: AppTextStyles.headline3,
          titleLarge: AppTextStyles.subtitle1,
          titleMedium: AppTextStyles.subtitle2,
          bodyLarge: AppTextStyles.bodyText1,
          bodyMedium: AppTextStyles.bodyText2,
          bodySmall: AppTextStyles.caption,
        ),
        cardTheme: const CardTheme(
          color: AppColors.cardBackgroundColor,
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(
              Radius.circular(10),
            ),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
            border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(10))));
  }

  static ThemeData get darkTheme {
    return ThemeData(
        primaryColor: AppColors.primaryColor,
        hintColor: AppColors.textLightColor,
        scaffoldBackgroundColor: AppColors.textColor,
        appBarTheme: AppBarTheme(
          color: AppColors.primaryColor,
          titleTextStyle: AppTextStyles.headline2.copyWith(color: Colors.white),
        ),
        textTheme: TextTheme(
          headlineLarge: AppTextStyles.headline1.copyWith(color: Colors.white),
          headlineMedium: AppTextStyles.headline2.copyWith(color: Colors.white),
          headlineSmall: AppTextStyles.headline3.copyWith(color: Colors.white),
          titleLarge: AppTextStyles.subtitle1.copyWith(color: Colors.white),
          titleMedium: AppTextStyles.subtitle2.copyWith(color: Colors.white),
          bodyLarge: AppTextStyles.bodyText1.copyWith(color: Colors.white),
          bodyMedium: AppTextStyles.bodyText2.copyWith(color: Colors.white),
          bodySmall: AppTextStyles.caption.copyWith(color: Colors.white),
        ),
        cardTheme: const CardTheme(
          color: AppColors.textLightColor,
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(
              Radius.circular(10),
            ),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
            border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(10))));
  }
}

class ThemeNotifier with ChangeNotifier {
  ThemeData _themeData = AppTheme.lightTheme;
  ThemeData get getTheme => _themeData;
  void setTheme(bool isDarkMode) {
    _themeData = isDarkMode ? AppTheme.darkTheme : AppTheme.lightTheme;
    notifyListeners();
  }
}
