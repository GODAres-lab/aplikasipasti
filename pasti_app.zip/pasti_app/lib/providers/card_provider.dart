import 'package:flutter/material.dart';
import 'package:pasti/core/models/card_info.dart';
import 'package:pasti/data/local/card_data.dart';

class CardProvider extends ChangeNotifier {
  List<CardInfo> _cardList = cardData;

  List<CardInfo> get cardList => _cardList;

  // Fungsi untuk memanipulasi data, contoh:
  // void addCard(CardInfo cardInfo) {
  //   _cardList.add(cardInfo);
  //   notifyListeners();
  // }

  void refresh() {
    notifyListeners();
  }
}
