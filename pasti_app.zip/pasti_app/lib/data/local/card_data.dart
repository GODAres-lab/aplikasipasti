import 'package:pasti/core/models/card_info.dart';

final List<CardInfo> cardData = [
  CardInfo(
    title: "Pengendalian Hama Wereng",
    subtitle: "Cara efektif mengatasi hama wereng pada tanaman padi.",
    imageUrl: "assets/images/wereng.png",
    content:
        "Wereng merupakan salah satu hama yang sering menyerang tanaman padi. Berikut adalah cara pengendaliannya: 1. Gunakan insektisida yang sesuai. 2. Rotasi tanaman. 3. Jaga kebersihan lahan.",
  ),
  CardInfo(
    title: "Penyakit Blas Daun",
    subtitle: "Mengenal dan mengatasi penyakit blas pada padi.",
    imageUrl: "assets/images/blas.png",
    content:
        "Penyakit blas daun dapat merusak tanaman padi. Cara mengatasinya: 1. Gunakan fungisida. 2. Pilih bibit unggul tahan penyakit. 3. Jaga kelembaban lahan.",
  ),
  CardInfo(
    title: "Pencegahan Hama",
    subtitle: "Tips mencegah hama pada tanaman padi.",
    imageUrl: "assets/images/pencegahan.png",
    content:
        "Pencegahan lebih baik daripada mengobati. Beberapa tips pencegahan hama: 1. Periksa tanaman secara berkala. 2. Gunakan perangkap hama. 3. Jaga kebersihan lahan.",
  ),
  CardInfo(
    title: "Teknik Pemupukan",
    subtitle: "Cara pemupukan yang benar untuk hasil panen maksimal.",
    imageUrl: "assets/images/pemupukan.png",
    content:
        "Pemupukan yang tepat sangat penting. Lakukan pemupukan sesuai dosis dan waktu yang dianjurkan. Gunakan pupuk organik dan anorganik secara seimbang.",
  ),
  CardInfo(
    title: "Irigasi yang Tepat",
    subtitle: "Pentingnya irigasi yang baik untuk pertumbuhan padi.",
    imageUrl: "assets/images/irigasi.png",
    content:
        "Air merupakan kebutuhan vital tanaman padi. Atur irigasi dengan baik agar tanaman mendapatkan air yang cukup. Hindari genangan air berlebih.",
  ),
  CardInfo(
    title: "Panen Padi",
    subtitle: "Tips dan trik memanen padi dengan hasil maksimal",
    imageUrl: "assets/images/panen.png",
    content:
        "Waktu panen padi sangat mempengaruhi kualitas hasil. Panenlah padi saat sudah mencapai kematangan optimal. Gunakan alat panen yang sesuai.",
  ),
  CardInfo(
      title: "Pengolahan Tanah",
      subtitle: "Teknik mengolah tanah yang baik untuk persiapan tanam",
      imageUrl: "assets/images/pengolahan_tanah.png",
      content:
          "Pengolahan tanah sangat penting untuk pertumbuhan tanaman. Lakukan pengolahan tanah dengan baik, seperti pembajakan dan penggaruan. Tambahkan pupuk dasar jika diperlukan."),
  CardInfo(
      title: "Bibit Unggul",
      subtitle: "Pentingnya memilih bibit unggul untuk hasil panen yang baik",
      imageUrl: "assets/images/bibit_unggul.png",
      content:
          "Bibit unggul sangat penting untuk mendapatkan hasil panen yang baik. Pilihlah bibit yang berkualitas dan tahan terhadap hama dan penyakit."),
];
