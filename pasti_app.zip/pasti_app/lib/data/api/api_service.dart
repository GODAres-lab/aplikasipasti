import 'package:dio/dio.dart';

class ApiService {
  final Dio _dio = Dio();

  Future<Map<String, dynamic>> fetchWeatherData(
      double latitude, double longitude) async {
    const apiKey = "YOUR_API_KEY";
    final response = await _dio.get(
        "https://api.openweathermap.org/data/2.5/weather?lat=$latitude&lon=$longitude&appid=$apiKey&units=metric");
    if (response.statusCode == 200) {
      return response.data;
    } else {
      throw Exception("Gagal mengambil data cuaca");
    }
  }
}
