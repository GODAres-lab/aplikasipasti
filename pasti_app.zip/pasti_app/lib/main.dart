import 'package:flutter/material.dart';
import 'package:pasti/app.dart';
import 'package:provider/provider.dart';
import 'package:pasti/providers/card_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    ChangeNotifierProvider(
      create: (context) => CardProvider(),
      child: const App(),
    ),
  );
}
