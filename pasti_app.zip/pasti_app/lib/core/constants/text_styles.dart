import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:pasti/core/constants/colors.dart';

class AppTextStyles {
  static TextStyle headline1 = GoogleFonts.poppins(
    fontSize: 32,
    fontWeight: FontWeight.bold,
    color: AppColors.textColor,
  );

  static TextStyle headline2 = GoogleFonts.poppins(
    fontSize: 24,
    fontWeight: FontWeight.bold,
    color: AppColors.textColor,
  );

  static TextStyle headline3 = GoogleFonts.poppins(
    fontSize: 20,
    fontWeight: FontWeight.bold,
    color: AppColors.textColor,
  );

  static TextStyle subtitle1 = GoogleFonts.poppins(
    fontSize: 18,
    fontWeight: FontWeight.w500,
    color: AppColors.textColor,
  );

  static TextStyle subtitle2 = GoogleFonts.poppins(
    fontSize: 16,
    fontWeight: FontWeight.w500,
    color: AppColors.textColor,
  );

  static TextStyle bodyText1 = GoogleFonts.poppins(
    fontSize: 16,
    color: AppColors.textColor,
  );

  static TextStyle bodyText2 = GoogleFonts.poppins(
    fontSize: 14,
    color: AppColors.textLightColor,
  );
  static TextStyle caption = GoogleFonts.poppins(
    fontSize: 12,
    color: AppColors.textLightColor,
  );
}
