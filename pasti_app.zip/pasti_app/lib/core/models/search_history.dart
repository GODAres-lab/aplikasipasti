class SearchHistory {
  final int? id;
  final String query;
  final int timestamp;

  SearchHistory({
    this.id,
    required this.query,
    required this.timestamp,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'query': query,
      'timestamp': timestamp,
    };
  }

  factory SearchHistory.fromMap(Map<String, dynamic> map) {
    return SearchHistory(
      id: map['id'],
      query: map['query'],
      timestamp: map['timestamp'],
    );
  }
}
