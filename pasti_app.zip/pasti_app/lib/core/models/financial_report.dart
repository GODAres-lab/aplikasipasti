class FinancialReport {
  final int? id;
  final String tanggal;
  final double income;
  final double expense;
  final double balance;

  FinancialReport({
    this.id,
    required this.tanggal,
    required this.income,
    required this.expense,
    required this.balance,
  });
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'tanggal': tanggal,
      'income': income,
      'expense': expense,
      'balance': balance,
    };
  }

  factory FinancialReport.fromMap(Map<String, dynamic> map) {
    return FinancialReport(
        id: map['id'],
        tanggal: map['tanggal'],
        income: map['income'],
        expense: map['expense'],
        balance: map['balance']);
  }
}
