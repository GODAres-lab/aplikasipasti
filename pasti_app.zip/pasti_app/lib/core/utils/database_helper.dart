import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:pasti/core/models/search_history.dart';
import 'package:pasti/core/models/financial_report.dart';

class DatabaseHelper {
  static const _databaseName = "pasti.db";
  static const _databaseVersion = 1;

  static const searchHistoryTable = "search_history";
  static const financialReportTable = "financial_reports";

  // make this a singleton class
  DatabaseHelper._privateConstructor();

  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final databasePath = await getDatabasesPath();
    final path = join(databasePath, _databaseName);

    return await openDatabase(path,
        version: _databaseVersion, onCreate: _onCreate);
  }

  Future _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE $searchHistoryTable (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        query TEXT NOT NULL,
        timestamp INTEGER NOT NULL
      )
    ''');
    await db.execute('''
        CREATE TABLE $financialReportTable (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          tanggal TEXT NOT NULL,
          income REAL NOT NULL,
          expense REAL NOT NULL,
          balance REAL NOT NULL
        )
      ''');
  }

  // search history table function
  Future<int> insertSearchHistory(SearchHistory history) async {
    final db = await instance.database;
    return await db.insert(searchHistoryTable, history.toMap());
  }

  Future<List<SearchHistory>> getSearchHistory() async {
    final db = await instance.database;
    final List<Map<String, dynamic>> maps =
        await db.query(searchHistoryTable, orderBy: "timestamp DESC");
    return List.generate(maps.length, (index) {
      return SearchHistory.fromMap(maps[index]);
    });
  }

  Future<int> deleteSearchHistory(int id) async {
    final db = await instance.database;
    return await db
        .delete(searchHistoryTable, where: 'id = ?', whereArgs: [id]);
  }

  Future<int> deleteAllSearchHistory() async {
    final db = await instance.database;
    return await db.delete(searchHistoryTable);
  }

  // financial report table function
  Future<int> insertFinancialReport(FinancialReport report) async {
    final db = await instance.database;
    return await db.insert(financialReportTable, report.toMap());
  }

  Future<List<FinancialReport>> getFinancialReports() async {
    final db = await instance.database;
    final List<Map<String, dynamic>> maps =
        await db.query(financialReportTable, orderBy: "tanggal DESC");
    return List.generate(maps.length, (index) {
      return FinancialReport.fromMap(maps[index]);
    });
  }

  Future<int> deleteAllFinancialReport() async {
    final db = await instance.database;
    return await db.delete(financialReportTable);
  }

  Future<int> deleteFinancialReport(int id) async {
    final db = await instance.database;
    return await db
        .delete(financialReportTable, where: 'id = ?', whereArgs: [id]);
  }
}
