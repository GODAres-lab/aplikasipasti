String calculateFertilizer(int nitrogen, int phosphorus, int potassium) {
  if (nitrogen > 200 || phosphorus > 100 || potassium > 150) {
    return "Perlu perbaikan kondisi tanah";
  } else if (nitrogen > 100 && phosphorus > 50 && potassium > 75) {
    return "Kebutuhan pupuk sedang, Gunakan pupuk NPK dengan dosis sedang";
  } else {
    return "Kebutuhan pupuk rendah, Gunakan pupuk organik";
  }
}
